## Bot Commands
This commands will be visible to all your Bot users as command menu, to help them discovering your Bot's functionality.<br>
### Add following commands in BotFather:
```
start - Start the Bot
sa - Upload the Serivce Account zip file to use the Bot
folders - Select the Shared Drives where you wish to save your files and folders
help - Get Information about the Bot
ban - Ban a Telegram User ID from using the Bot
unban - Reallow a Telegram User ID from using the Bot that was earlier banned
vip - Add a Telegram User ID to the VIP Access List
unvip - Remove a Telegram User ID to the VIP Access List
id - Get your Telegram User  ID
contact - Get the contacts details of the owner of the Bot
```
<b>User Commands:</b>
```
start - Start the Bot
sa - Upload the Serivce Account zip file to use the Bot
folders - Select the Shared Drives where you wish to save your files and folders
help - Get Information about the Bot
id - Get your Telegram User  ID
contact - Get the contacts details of the owner of the Bot
```
<b>Admin-only Commands:</b>
```
ban - Ban a Telegram User ID from using the Bot
unban - Reallow a Telegram User ID from using the Bot that was earlier banned
vip - Add a Telegram User ID to the VIP Access List
unvip - Remove a Telegram User ID to the VIP Access List
```
<b>⛔NOTICE: Adding this commands are optional, changing this commands from BotFather don't change it for Bot.</b>
